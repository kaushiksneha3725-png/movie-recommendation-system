"""
app.py
-------
Streamlit front-end for the Intelligent Movie Recommendation System.

Run with (from the project root):
    streamlit run app/app.py

The app loads pre-trained artifacts (see src/train.py) so it starts
quickly and never recomputes the TF-IDF matrix on launch.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import joblib
import pandas as pd
import streamlit as st

# Allow `from src...` imports when Streamlit runs this file directly.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.api_client import get_poster_url, is_api_configured  # noqa: E402
from src.recommendation_engine import (  # noqa: E402
    MovieNotFoundError,
    RankingWeights,
    RecommendationEngine,
)
from src.utils import (  # noqa: E402
    MOVIES_ARTIFACT_PATH,
    TFIDF_MATRIX_PATH,
    get_logger,
)

# Load .env file (TMDB_API_KEY) if python-dotenv is available.
try:
    from dotenv import load_dotenv

    load_dotenv(PROJECT_ROOT / ".env")
except ImportError:
    pass

logger = get_logger(__name__)

st.set_page_config(
    page_title="Intelligent Movie Recommendation System",
    page_icon="🎬",
    layout="wide",
)

# ---------------------------------------------------------------------------
# Styling — a small amount of custom CSS to avoid a "default CRUD app" look.
# ---------------------------------------------------------------------------
st.markdown(
    """
    <style>
    .movie-card {
        background: #14161f;
        border-radius: 14px;
        padding: 14px;
        margin-bottom: 18px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.25);
        height: 100%;
    }
    .movie-title {
        font-weight: 700;
        font-size: 1.02rem;
        margin: 8px 0 2px 0;
        line-height: 1.2rem;
        min-height: 2.4rem;
    }
    .movie-meta {
        color: #a9adc1;
        font-size: 0.82rem;
        margin-bottom: 6px;
    }
    .score-badge {
        display: inline-block;
        background: #2e6bff;
        color: white;
        border-radius: 999px;
        padding: 2px 10px;
        font-size: 0.75rem;
        font-weight: 600;
        margin-bottom: 6px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


# ---------------------------------------------------------------------------
# Cached artifact loading
# ---------------------------------------------------------------------------
@st.cache_resource(show_spinner="Loading trained model artifacts...")
def load_engine() -> RecommendationEngine:
    if not MOVIES_ARTIFACT_PATH.exists() or not TFIDF_MATRIX_PATH.exists():
        st.error(
            "Model artifacts not found. Please run the training script first:\n\n"
            "`python -m src.train`\n\n"
            "from the project root, then restart this app."
        )
        st.stop()
    movies = joblib.load(MOVIES_ARTIFACT_PATH)
    tfidf_matrix = joblib.load(TFIDF_MATRIX_PATH)
    return RecommendationEngine(movies, tfidf_matrix)


def render_movie_card(row: pd.Series, column, show_score: bool = False) -> None:
    """Render a single movie as a styled card inside the given Streamlit
    column. Handles a missing/failed poster gracefully.
    """
    with column:
        st.markdown('<div class="movie-card">', unsafe_allow_html=True)
        try:
            poster_url = get_poster_url(row.get("id"))
        except Exception:  # noqa: BLE001 - never let a poster failure crash the UI
            poster_url = None
        if poster_url:
            st.image(poster_url, use_container_width=True)

        if show_score and "final_score" in row:
            st.markdown(
                f'<span class="score-badge">Match {row["final_score"] * 100:.0f}%</span>',
                unsafe_allow_html=True,
            )

        st.markdown(f'<div class="movie-title">{row["title"]}</div>', unsafe_allow_html=True)
        year = row.get("release_year", "")
        rating = row.get("vote_average", 0)
        st.markdown(
            f'<div class="movie-meta">⭐ {rating:.1f} &nbsp;|&nbsp; {year} '
            f'&nbsp;|&nbsp; {row.get("genres_display", "")}</div>',
            unsafe_allow_html=True,
        )
        overview = str(row.get("overview", ""))
        short_overview = overview[:140] + ("…" if len(overview) > 140 else "")
        st.caption(short_overview)
        st.markdown("</div>", unsafe_allow_html=True)


def render_movie_grid(df: pd.DataFrame, show_score: bool = False, columns_per_row: int = 5) -> None:
    rows = [df.iloc[i : i + columns_per_row] for i in range(0, len(df), columns_per_row)]
    for chunk in rows:
        cols = st.columns(columns_per_row)
        for col, (_, row) in zip(cols, chunk.iterrows()):
            render_movie_card(row, col, show_score=show_score)


# ---------------------------------------------------------------------------
# App body
# ---------------------------------------------------------------------------
engine = load_engine()
movies_df = engine.movies

st.title("🎬 Intelligent Movie Recommendation System")
st.markdown(
    "##### Discover movies you'll love using Machine Learning and Content-Based Recommendation."
)

if not is_api_configured():
    st.info(
        "TMDB_API_KEY is not configured, so posters will show a placeholder "
        "image. See `.env.example` for setup instructions. The recommendation "
        "engine itself works fully offline.",
        icon="ℹ️",
    )

tab_recommend, tab_popular, tab_about = st.tabs(
    ["🔎 Get Recommendations", "🔥 Popular Movies", "ℹ️ About This Project"]
)

# --- Tab 1: Recommendations -------------------------------------------------
with tab_recommend:
    st.subheader("Find movies similar to one you already like")

    col_search, col_n = st.columns([3, 1])
    with col_search:
        query = st.text_input("Search for a movie", placeholder="e.g. The Dark Knight")
    with col_n:
        n_results = st.slider("Number of recommendations", min_value=5, max_value=20, value=10)

    matched_titles = engine.search_titles(query) if query else []

    selected_title = None
    if matched_titles:
        selected_title = st.selectbox("Select the exact movie", matched_titles)
    elif query:
        st.warning("No movies matched your search. Try a different title.")

    with st.expander("⚙️ Advanced: ranking options"):
        use_hybrid = st.checkbox(
            "Use hybrid ranking (blend similarity + rating + popularity)", value=True
        )
        sim_w = st.slider("Similarity weight", 0.0, 1.0, 0.7)
        rating_w = st.slider("Rating weight", 0.0, 1.0, 0.2)
        pop_w = st.slider("Popularity weight", 0.0, 1.0, 0.1)
        min_votes = st.number_input(
            "Minimum vote count (avoids obscure movies with few votes dominating)",
            min_value=0,
            value=20,
            step=10,
        )

    if selected_title:
        details = engine.get_movie_details(selected_title)
        st.markdown("---")
        detail_col1, detail_col2 = st.columns([1, 3])
        with detail_col1:
            poster = get_poster_url(details.get("id"))
            if poster:
                st.image(poster, use_container_width=True)
        with detail_col2:
            st.markdown(f"### {details['title']} ({details.get('release_year', 'N/A')})")
            st.write(
                f"⭐ **{details['vote_average']:.1f}**/10  |  "
                f"🗳️ {int(details['vote_count'])} votes  |  "
                f"🎭 {details['genres_display']}"
            )
            st.write(f"🎬 Director: {details['director_display']}")
            st.write(f"👥 Cast: {details['cast_display']}")
            st.write(details["overview"])

        st.markdown("### Recommended for you")
        try:
            weights = RankingWeights(
                similarity_weight=sim_w,
                rating_weight=rating_w,
                popularity_weight=pop_w,
                minimum_vote_count=int(min_votes),
            )
            recommendations = engine.recommend_movies(
                selected_title,
                n=n_results,
                use_hybrid_ranking=use_hybrid,
                weights=weights,
            )
            render_movie_grid(recommendations, show_score=use_hybrid)
        except MovieNotFoundError:
            st.error("That movie could not be found in the dataset.")
    else:
        st.caption("Start typing a movie title above to get personalized recommendations.")

# --- Tab 2: Popular movies --------------------------------------------------
with tab_popular:
    st.subheader("Discover popular & highly rated movies")

    all_genres = sorted(
        {g.strip() for row in movies_df["genres_display"] for g in row.split(",") if g.strip()}
    )
    col_g, col_r = st.columns(2)
    with col_g:
        genre_filter = st.selectbox("Filter by genre (optional)", ["All"] + all_genres)
    with col_r:
        min_rating = st.slider("Minimum rating", 0.0, 10.0, 6.0, step=0.5)

    popular = engine.popular_movies(
        n=20, minimum_vote_count=100, genre=None if genre_filter == "All" else genre_filter
    )
    popular = popular[popular["vote_average"] >= min_rating]

    if popular.empty:
        st.warning("No movies match these filters. Try loosening the rating or genre filter.")
    else:
        render_movie_grid(popular, show_score=False)

# --- Tab 3: About ------------------------------------------------------------
with tab_about:
    st.subheader("About this project")
    st.markdown(
        """
This system recommends movies using **content-based filtering**:

1. Each movie's genres, keywords, top cast, director and overview are
   combined into a single text feature (`tags`).
2. **TF-IDF** converts that text into numerical vectors, weighting
   distinctive words (a rare keyword, a specific actor) more heavily
   than generic ones.
3. **Cosine similarity** compares the selected movie's vector against
   every other movie to find the closest matches.
4. An optional **hybrid ranking** step blends that similarity score with
   normalized rating and popularity, so recommendations are not just
   "textually similar" but also generally well-regarded.

Dataset: TMDB 5000 Movie Dataset (movies + credits).
See `README.md` in the project repository for the full architecture,
evaluation notes and viva Q&A.
        """
    )
    st.metric("Movies in catalogue", len(movies_df))
