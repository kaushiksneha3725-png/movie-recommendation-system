"""
api_client.py
---------------
Thin wrapper around the TMDB (The Movie Database) REST API.

Used to fetch live metadata that is nicer for a UI than the static CSV
alone -- mainly poster/backdrop images, but also serves as a live
cross-check for rating/overview/genres.

Design notes
------------
- The API key is NEVER hardcoded. It is read from the TMDB_API_KEY
  environment variable (see .env.example).
- Every network call is wrapped in try/except with a timeout, and on
  ANY failure (missing key, network timeout, 4xx/5xx response, malformed
  JSON) the function returns a safe fallback value instead of raising,
  so the Streamlit app never crashes because of the network.
- Results are cached in-memory per process to avoid repeat calls for the
  same movie during one session (Streamlit re-runs the script on every
  interaction).
"""

from __future__ import annotations

from functools import lru_cache

import requests

from src.utils import get_env, get_logger

logger = get_logger(__name__)

TMDB_BASE_URL = "https://api.themoviedb.org/3"
TMDB_IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w500"
REQUEST_TIMEOUT_SECONDS = 5

# Shown in the UI whenever a poster cannot be retrieved (missing key,
# network failure, or the movie has no poster on TMDB).
PLACEHOLDER_POSTER_URL = (
    "https://via.placeholder.com/500x750.png?text=Poster+Not+Available"
)


def _get_api_key() -> str | None:
    key = get_env("TMDB_API_KEY")
    if not key:
        logger.warning(
            "TMDB_API_KEY is not set. Poster/backdrop images will fall back "
            "to placeholders. See .env.example for setup instructions."
        )
    return key


@lru_cache(maxsize=512)
def fetch_movie_details_by_id(tmdb_id: int) -> dict:
    """Fetch live movie details from TMDB by numeric movie id.

    Returns an empty dict on any failure so callers can safely fall back
    to locally available (CSV) data instead of crashing.
    """
    api_key = _get_api_key()
    if not api_key or not tmdb_id:
        return {}

    url = f"{TMDB_BASE_URL}/movie/{int(tmdb_id)}"
    try:
        response = requests.get(
            url,
            params={"api_key": api_key, "language": "en-US"},
            timeout=REQUEST_TIMEOUT_SECONDS,
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.Timeout:
        logger.warning("TMDB request timed out for movie_id=%s", tmdb_id)
    except requests.exceptions.RequestException as exc:
        logger.warning("TMDB request failed for movie_id=%s: %s", tmdb_id, exc)
    except ValueError:
        logger.warning("TMDB returned invalid JSON for movie_id=%s", tmdb_id)
    return {}


def get_poster_url(tmdb_id: int) -> str:
    """Return a full poster image URL, or a placeholder if unavailable."""
    details = fetch_movie_details_by_id(tmdb_id)
    poster_path = details.get("poster_path")
    if poster_path:
        return f"{TMDB_IMAGE_BASE_URL}{poster_path}"
    return PLACEHOLDER_POSTER_URL


def get_backdrop_url(tmdb_id: int) -> str | None:
    """Return a full backdrop image URL, or None if unavailable."""
    details = fetch_movie_details_by_id(tmdb_id)
    backdrop_path = details.get("backdrop_path")
    return f"{TMDB_IMAGE_BASE_URL}{backdrop_path}" if backdrop_path else None


def is_api_configured() -> bool:
    """Whether a TMDB API key is present -- used by the UI to show a
    friendly setup notice instead of silently degraded behaviour."""
    return _get_api_key() is not None


if __name__ == "__main__":
    # Quick manual smoke test: python -m src.api_client
    test_id = 19995  # Avatar
    print("API configured:", is_api_configured())
    print("Poster URL:", get_poster_url(test_id))
