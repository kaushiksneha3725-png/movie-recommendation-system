"""
utils.py
--------
Small, reusable helper functions shared across the preprocessing,
feature-engineering, recommendation and API modules.

Keeping these in one place avoids duplicating logic (e.g. safe JSON
parsing, path handling) in multiple files.
"""

from __future__ import annotations

import ast
import logging
import os
from pathlib import Path
from typing import Any, List

# ---------------------------------------------------------------------------
# Project paths (single source of truth, used by every other module)
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_RAW_DIR = PROJECT_ROOT / "data" / "raw"
DATA_PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"
MODELS_DIR = PROJECT_ROOT / "models"

MOVIES_CSV = DATA_RAW_DIR / "tmdb_5000_movies.csv"
CREDITS_CSV = DATA_RAW_DIR / "tmdb_5000_credits.csv"
PROCESSED_MOVIES_PATH = DATA_PROCESSED_DIR / "processed_movies.csv"

TFIDF_VECTORIZER_PATH = MODELS_DIR / "tfidf_vectorizer.pkl"
TFIDF_MATRIX_PATH = MODELS_DIR / "tfidf_matrix.pkl"
SIMILARITY_MATRIX_PATH = MODELS_DIR / "similarity_matrix.pkl"
MOVIES_ARTIFACT_PATH = MODELS_DIR / "movies_artifact.pkl"


def get_logger(name: str) -> logging.Logger:
    """Return a configured module-level logger.

    Using a shared helper keeps log formatting consistent across the
    preprocessing, training and app entry points.
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%H:%M:%S",
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


def safe_literal_eval(value: Any) -> List[Any]:
    """Safely parse a stringified Python/JSON-like list (as found in the
    TMDB 'genres', 'keywords', 'cast' and 'crew' columns) into a real list.

    The TMDB CSV stores nested structures such as::

        "[{'id': 28, 'name': 'Action'}, {'id': 12, 'name': 'Adventure'}]"

    ``ast.literal_eval`` converts this text back into Python objects.
    We wrap it in a try/except because a handful of rows may contain
    malformed or missing data, and the pipeline must not crash on those.
    """
    if value is None:
        return []
    if isinstance(value, list):
        return value
    try:
        parsed = ast.literal_eval(value)
        return parsed if isinstance(parsed, list) else []
    except (ValueError, SyntaxError, TypeError):
        return []


def normalize_text(text: str) -> str:
    """Lower-case text and collapse internal whitespace.

    Used on the free-text 'overview' field before it is merged into the
    combined 'tags' feature so that casing does not create spurious
    distinct TF-IDF tokens (e.g. 'Adventure' vs 'adventure').
    """
    if not isinstance(text, str):
        return ""
    return " ".join(text.lower().split())


def ensure_dirs() -> None:
    """Create the data/models directories if they do not already exist."""
    for directory in (DATA_RAW_DIR, DATA_PROCESSED_DIR, MODELS_DIR):
        directory.mkdir(parents=True, exist_ok=True)


def get_env(key: str, default: str | None = None) -> str | None:
    """Thin wrapper around os.getenv kept here so every module fetches
    environment variables the same way (and so tests can monkeypatch
    a single function if needed)."""
    return os.getenv(key, default)
