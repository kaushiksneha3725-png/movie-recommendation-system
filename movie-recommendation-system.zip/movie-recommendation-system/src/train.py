"""
train.py
---------
One-time (or "whenever the dataset changes") build script.

Running this script:
  1. Loads the raw TMDB CSVs.
  2. Cleans and preprocesses them.
  3. Builds TF-IDF features.
  4. Saves the processed dataframe, the fitted vectorizer and the TF-IDF
     matrix to disk (models/ and data/processed/).

The Streamlit app loads these saved artifacts instead of recomputing
TF-IDF on every startup, which would be slow and wasteful. Cosine
similarity itself is computed on-demand per query in
RecommendationEngine (a 4803x4803 similarity matrix would be ~185MB in
memory, so it's cheaper to compute one row at a time via linear_kernel
than to precompute and store the full matrix).

Run with:
    python -m src.train
"""

from __future__ import annotations

import joblib

from src.data_preprocessing import run_preprocessing
from src.feature_engineering import build_tfidf_features
from src.utils import (
    MOVIES_ARTIFACT_PATH,
    PROCESSED_MOVIES_PATH,
    TFIDF_MATRIX_PATH,
    TFIDF_VECTORIZER_PATH,
    ensure_dirs,
    get_logger,
)

logger = get_logger(__name__)


def main() -> None:
    ensure_dirs()

    logger.info("Step 1/3: Running data preprocessing pipeline...")
    processed = run_preprocessing()
    processed.to_csv(PROCESSED_MOVIES_PATH, index=False)
    logger.info("Saved processed dataset -> %s", PROCESSED_MOVIES_PATH)

    logger.info("Step 2/3: Building TF-IDF features...")
    vectorizer, tfidf_matrix = build_tfidf_features(processed["tags"])
    joblib.dump(vectorizer, TFIDF_VECTORIZER_PATH)
    joblib.dump(tfidf_matrix, TFIDF_MATRIX_PATH)
    logger.info("Saved TF-IDF vectorizer -> %s", TFIDF_VECTORIZER_PATH)
    logger.info("Saved TF-IDF matrix -> %s", TFIDF_MATRIX_PATH)

    logger.info("Step 3/3: Saving movies artifact for fast app startup...")
    joblib.dump(processed, MOVIES_ARTIFACT_PATH)
    logger.info("Saved movies artifact -> %s", MOVIES_ARTIFACT_PATH)

    logger.info(
        "Training complete. %d movies processed, TF-IDF vocabulary size %d.",
        len(processed),
        len(vectorizer.vocabulary_),
    )


if __name__ == "__main__":
    main()
