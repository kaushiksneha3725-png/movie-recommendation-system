"""
recommendation_engine.py
--------------------------
The core ML logic of the project.

Pipeline
--------
User selects Movie
        |
Find Movie Index
        |
Get TF-IDF Vector
        |
Calculate Cosine Similarity
        |
Sort Similar Movies
        |
Filter already-selected movie
        |
(optional) Re-rank with rating/popularity
        |
Return Top N Recommendations

Why cosine similarity?
-----------------------
TF-IDF vectors live in a very high-dimensional, sparse space where a
movie's vector length mostly reflects how much text it has, not how
"important" it is. Cosine similarity measures the *angle* between two
vectors rather than their magnitude, so it naturally compares movies on
the *pattern* of words they share, regardless of overview length. That
makes it the standard, well-justified choice for TF-IDF-based
content similarity.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity, linear_kernel

from src.utils import get_logger

logger = get_logger(__name__)


class MovieNotFoundError(Exception):
    """Raised when a requested movie title does not exist in the dataset."""


@dataclass
class RankingWeights:
    """Configurable weights for the hybrid re-ranking score.

    These are NOT scientifically optimized values -- they are reasonable,
    hand-picked defaults that can be tuned from the Streamlit sidebar.
    final_score = similarity_weight * similarity
                + rating_weight * normalized_rating
                + popularity_weight * normalized_popularity
    """

    similarity_weight: float = 0.7
    rating_weight: float = 0.2
    popularity_weight: float = 0.1
    minimum_vote_count: int = 20  # filters out movies with too few votes

    def normalized(self) -> "RankingWeights":
        """Return a copy whose similarity/rating/popularity weights sum to 1."""
        total = self.similarity_weight + self.rating_weight + self.popularity_weight
        if total <= 0:
            return RankingWeights()
        return RankingWeights(
            similarity_weight=self.similarity_weight / total,
            rating_weight=self.rating_weight / total,
            popularity_weight=self.popularity_weight / total,
            minimum_vote_count=self.minimum_vote_count,
        )


class RecommendationEngine:
    """Content-based movie recommender built on TF-IDF + cosine similarity,
    with an optional weighted hybrid re-ranking step (similarity + rating +
    popularity).
    """

    def __init__(self, movies: pd.DataFrame, tfidf_matrix):
        self.movies = movies.reset_index(drop=True)
        self.tfidf_matrix = tfidf_matrix
        self._title_to_index = {
            title.lower(): idx for idx, title in enumerate(self.movies["title"])
        }
        # Pre-compute normalized rating/popularity columns once so re-ranking
        # at request time is just an array lookup, not a recomputation.
        self.movies["norm_rating"] = self._normalize(self.movies["vote_average"])
        self.movies["norm_popularity"] = self._normalize(self.movies["popularity"])

    @staticmethod
    def _normalize(series: pd.Series) -> pd.Series:
        min_v, max_v = series.min(), series.max()
        if max_v - min_v == 0:
            return series * 0
        return (series - min_v) / (max_v - min_v)

    def find_movie_index(self, title: str) -> int:
        """Look up a movie's row index by (case-insensitive) exact title."""
        idx = self._title_to_index.get(title.strip().lower())
        if idx is None:
            raise MovieNotFoundError(f"Movie '{title}' was not found in the dataset.")
        return idx

    def search_titles(self, query: str, limit: int = 10) -> list[str]:
        """Simple substring search used to power the UI's search box."""
        query = query.strip().lower()
        if not query:
            return []
        matches = [t for t in self.movies["title"] if query in t.lower()]
        return matches[:limit]

    def _similarity_scores_for(self, movie_idx: int) -> np.ndarray:
        """Cosine similarity between one movie's TF-IDF vector and every
        other movie's vector.

        linear_kernel is mathematically equivalent to cosine_similarity
        when the input vectors are L2-normalized (which TfidfVectorizer's
        output is, by default), and is faster -- this is a well-known
        optimization for TF-IDF similarity search.
        """
        return linear_kernel(self.tfidf_matrix[movie_idx], self.tfidf_matrix).flatten()

    def recommend_movies(
        self,
        movie_title: str,
        n: int = 10,
        use_hybrid_ranking: bool = True,
        weights: RankingWeights | None = None,
    ) -> pd.DataFrame:
        """Return the top-N recommended movies for a given movie title.

        Parameters
        ----------
        movie_title: exact title of the movie the user selected.
        n: number of recommendations to return.
        use_hybrid_ranking: if True, blend content similarity with
            normalized rating and popularity (see RankingWeights). If
            False, rank purely by cosine similarity.
        weights: optional custom RankingWeights; defaults are used if None.

        Raises
        ------
        MovieNotFoundError if the title does not exist in the dataset.
        """
        idx = self.find_movie_index(movie_title)
        sim_scores = self._similarity_scores_for(idx)

        candidates = self.movies.copy()
        candidates["similarity"] = sim_scores

        # Filter out the queried movie itself.
        candidates = candidates.drop(index=idx)

        weights = (weights or RankingWeights()).normalized()

        if use_hybrid_ranking:
            # Minimum vote-count threshold: without this, an obscure movie
            # with a single 10/10 vote could dominate results ahead of a
            # broadly well-reviewed film. Movies below the threshold are
            # kept but their rating contribution is not allowed to inflate
            # the score -- they simply fall back to a similarity-only score.
            eligible = candidates["vote_count"] >= weights.minimum_vote_count
            candidates["final_score"] = candidates["similarity"] * weights.similarity_weight
            candidates.loc[eligible, "final_score"] += (
                candidates.loc[eligible, "norm_rating"] * weights.rating_weight
                + candidates.loc[eligible, "norm_popularity"] * weights.popularity_weight
            )
            ranking_column = "final_score"
        else:
            ranking_column = "similarity"

        top = candidates.sort_values(ranking_column, ascending=False).head(n)
        return top

    def popular_movies(
        self, n: int = 10, minimum_vote_count: int = 100, genre: str | None = None
    ) -> pd.DataFrame:
        """Simple popularity-based listing (no similarity involved), used
        for the "Discover popular movies" tab.
        """
        subset = self.movies[self.movies["vote_count"] >= minimum_vote_count]
        if genre:
            subset = subset[
                subset["genres_display"].str.contains(genre, case=False, na=False)
            ]
        return subset.sort_values(
            ["vote_average", "popularity"], ascending=False
        ).head(n)

    def get_movie_details(self, movie_title: str) -> pd.Series:
        """Return the full metadata row for one movie."""
        idx = self.find_movie_index(movie_title)
        return self.movies.iloc[idx]


if __name__ == "__main__":
    from src.data_preprocessing import run_preprocessing
    from src.feature_engineering import build_tfidf_features

    processed = run_preprocessing()
    _, matrix = build_tfidf_features(processed["tags"])
    engine = RecommendationEngine(processed, matrix)

    sample_title = processed["title"].iloc[0]
    print(f"Recommendations for: {sample_title}\n")
    print(engine.recommend_movies(sample_title, n=5)[["title", "similarity", "final_score"]])
