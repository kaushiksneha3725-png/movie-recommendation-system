"""
feature_engineering.py
------------------------
Converts the combined 'tags' text column into numerical features using
TF-IDF (Term Frequency - Inverse Document Frequency).

Why TF-IDF for this problem?
-----------------------------
Each movie's 'tags' field is a short "bag of words" built from its genres,
keywords, cast, director and overview. TF-IDF is well suited here because:

1. It rewards words that are frequent *within one movie's tags* but rare
   *across the whole catalogue* -- e.g. a niche keyword like "time-travel"
   or a specific actor's name says a lot more about a movie's identity
   than a generic word like "life" or "story", which appears everywhere
   and gets down-weighted automatically.
2. It requires no labelled training data (unlike supervised embeddings),
   which fits a content-based recommender where we only have item
   metadata, not user interaction history.
3. It is fast, memory-efficient and fully interpretable -- each vector
   dimension maps back to a real word, which makes the system easy to
   explain in a viva.
"""

from __future__ import annotations

import pandas as pd
from scipy.sparse import csr_matrix
from sklearn.feature_extraction.text import TfidfVectorizer

from src.utils import get_logger

logger = get_logger(__name__)


def build_tfidf_features(
    tags: pd.Series,
    max_features: int = 5000,
    ngram_range: tuple[int, int] = (1, 2),
) -> tuple[TfidfVectorizer, csr_matrix]:
    """Fit a TfidfVectorizer on the 'tags' column and return both the
    fitted vectorizer (needed later to transform new/unseen text) and the
    resulting sparse TF-IDF matrix.

    Parameters
    ----------
    tags: the combined text feature, one string per movie.
    max_features: caps the vocabulary size to the top-N terms ranked by
        corpus frequency. This keeps the similarity matrix computation
        fast and avoids overfitting to extremely rare tokens (typos,
        one-off keywords) while still capturing the important signal.
    ngram_range: (1, 2) includes both single words ("action") and
        two-word phrases ("science fiction"), which helps distinguish
        movies whose meaning depends on word pairs.

    Returns
    -------
    (vectorizer, tfidf_matrix)
    """
    logger.info(
        "Fitting TF-IDF vectorizer (max_features=%d, ngram_range=%s)...",
        max_features,
        ngram_range,
    )
    vectorizer = TfidfVectorizer(
        stop_words="english",   # remove common English stopwords (the, and, of, ...)
        max_features=max_features,
        ngram_range=ngram_range,
        min_df=2,                # ignore terms that appear in only one movie (noise)
    )
    tfidf_matrix = vectorizer.fit_transform(tags.fillna(""))
    logger.info("TF-IDF matrix shape: %s", tfidf_matrix.shape)
    return vectorizer, tfidf_matrix


if __name__ == "__main__":
    from src.data_preprocessing import run_preprocessing

    processed = run_preprocessing()
    vec, matrix = build_tfidf_features(processed["tags"])
    print("Vocabulary size:", len(vec.vocabulary_))
    print("Matrix shape:", matrix.shape)
