"""
data_preprocessing.py
----------------------
Loads the raw TMDB 5000 CSV files, cleans them, merges movies with
credits, and produces a single "tags" text feature per movie that the
feature-engineering stage will vectorize with TF-IDF.

This module has no Streamlit / API dependencies so it can be imported
from a notebook, a script, or the training pipeline without side effects.
"""

from __future__ import annotations

import pandas as pd

from src.utils import (
    CREDITS_CSV,
    MOVIES_CSV,
    get_logger,
    normalize_text,
    safe_literal_eval,
)

logger = get_logger(__name__)

# Number of top-billed cast members to keep per movie. Keeping this small
# avoids the "tags" text being dominated by minor cast and keeps the
# TF-IDF vocabulary meaningful.
TOP_CAST_COUNT = 3


def load_raw_data(movies_path=MOVIES_CSV, credits_path=CREDITS_CSV) -> pd.DataFrame:
    """Load and merge the movies and credits CSV files on movie title.

    Raises
    ------
    FileNotFoundError
        If either CSV is missing, with a message that tells the user
        exactly where to place the dataset (see README > Dataset Setup).
    """
    if not movies_path.exists() or not credits_path.exists():
        raise FileNotFoundError(
            "TMDB dataset not found. Expected files:\n"
            f"  {movies_path}\n  {credits_path}\n"
            "Download the 'TMDB 5000 Movie Dataset' (movies + credits CSVs) "
            "and place both files in data/raw/. See README.md > Dataset Setup."
        )

    logger.info("Loading raw CSV files...")
    movies = pd.read_csv(movies_path)
    credits = pd.read_csv(credits_path)

    # The credits file uses 'movie_id' + 'title'; movies uses 'id' + 'title'.
    # We merge on title (as in the classic TMDB-5000 recommender pipeline)
    # and keep 'id' as the canonical movie identifier.
    credits = credits.rename(columns={"movie_id": "id"})
    merged = movies.merge(credits[["id", "cast", "crew"]], on="id", how="left")
    logger.info("Merged dataset shape: %s", merged.shape)
    return merged


def extract_genre_names(genres_raw) -> list[str]:
    """Turn the JSON-like 'genres' column into a flat list of genre names."""
    return [item.get("name", "") for item in safe_literal_eval(genres_raw)]


def extract_keyword_names(keywords_raw) -> list[str]:
    """Turn the JSON-like 'keywords' column into a flat list of keyword names."""
    return [item.get("name", "") for item in safe_literal_eval(keywords_raw)]


def extract_top_cast(cast_raw, top_n: int = TOP_CAST_COUNT) -> list[str]:
    """Return the names of the top-N billed cast members (spaces stripped
    so multi-word names, e.g. 'Sam Worthington', form a single token)."""
    cast_list = safe_literal_eval(cast_raw)
    names = [member.get("name", "") for member in cast_list[:top_n]]
    return [name.replace(" ", "") for name in names]


def extract_director(crew_raw) -> list[str]:
    """Pull the director's name out of the 'crew' column.

    The crew list contains every department (writer, editor, director,
    producer, ...); we filter for job == 'Director'. Returned as a
    single-item list (space-stripped) so it merges cleanly into 'tags'.
    """
    crew_list = safe_literal_eval(crew_raw)
    for member in crew_list:
        if member.get("job") == "Director":
            return [member.get("name", "").replace(" ", "")]
    return []


def clean_dataset(df: pd.DataFrame) -> pd.DataFrame:
    """Apply the full cleaning pipeline: dedupe, handle missing values,
    extract structured fields, and build the combined 'tags' column.
    """
    df = df.copy()

    before = len(df)
    df = df.drop_duplicates(subset=["title"]).reset_index(drop=True)
    logger.info("Removed %d duplicate titles", before - len(df))

    # Only 'overview' realistically has missing values in this dataset;
    # rows with no overview carry very little content signal, so they are
    # dropped rather than silently filled with an empty string.
    before = len(df)
    df = df.dropna(subset=["overview"]).reset_index(drop=True)
    logger.info("Dropped %d rows with missing overview", before - len(df))

    # Fill remaining optional/numeric gaps rather than dropping more rows.
    df["tagline"] = df.get("tagline", "").fillna("")
    df["runtime"] = df.get("runtime", pd.Series(dtype=float)).fillna(
        df.get("runtime", pd.Series(dtype=float)).median()
    )
    df["vote_average"] = df["vote_average"].fillna(0.0)
    df["vote_count"] = df["vote_count"].fillna(0).astype(int)
    df["popularity"] = df["popularity"].fillna(0.0)

    # --- Structured field extraction -------------------------------------------------
    logger.info("Extracting genres, keywords, cast and director...")
    df["genres_list"] = df["genres"].apply(extract_genre_names)
    df["keywords_list"] = df["keywords"].apply(extract_keyword_names)
    df["cast_list"] = df["cast"].apply(extract_top_cast)
    df["director_list"] = df["crew"].apply(extract_director)

    # Human-readable comma-separated versions, useful for the UI.
    df["genres_display"] = df["genres_list"].apply(lambda x: ", ".join(x))
    df["director_display"] = df["director_list"].apply(
        lambda x: x[0] if x else "Unknown"
    )
    df["cast_display"] = df["cast_list"].apply(lambda x: ", ".join(x))

    # Release year, used for display and for the "filter by year" UI control.
    df["release_year"] = (
        pd.to_datetime(df["release_date"], errors="coerce").dt.year.fillna(0).astype(int)
    )

    # --- Combined text feature ("tags") -----------------------------------------------
    # Token lists (genres/keywords/cast/director) are joined with spaces so
    # each entry becomes a single TF-IDF token; the overview is normalized
    # free text. This mirrors classic content-based recommenders while
    # keeping every step traceable to a specific column.
    df["overview_clean"] = df["overview"].apply(normalize_text)
    df["tags"] = (
        df["overview_clean"]
        + " "
        + df["genres_list"].apply(lambda x: " ".join(x)).str.lower()
        + " "
        + df["keywords_list"].apply(lambda x: " ".join(x)).str.lower()
        + " "
        + df["cast_list"].apply(lambda x: " ".join(x)).str.lower()
        + " "
        + df["director_list"].apply(lambda x: " ".join(x)).str.lower()
    )
    df["tags"] = df["tags"].apply(normalize_text)

    columns_to_keep = [
        "id",
        "title",
        "overview",
        "tagline",
        "genres_display",
        "keywords_list",
        "cast_display",
        "director_display",
        "vote_average",
        "vote_count",
        "popularity",
        "release_date",
        "release_year",
        "runtime",
        "tags",
    ]
    result = df[columns_to_keep].reset_index(drop=True)
    logger.info("Final cleaned dataset shape: %s", result.shape)
    return result


def run_preprocessing() -> pd.DataFrame:
    """Convenience entry point used by the training script and notebook."""
    raw = load_raw_data()
    return clean_dataset(raw)


if __name__ == "__main__":
    processed = run_preprocessing()
    print(processed.head())
    print(f"\nProcessed {len(processed)} movies.")
