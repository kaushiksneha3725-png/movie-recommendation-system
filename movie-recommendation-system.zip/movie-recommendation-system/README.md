# Intelligent Movie Recommendation System

A production-style, content-based movie recommendation system built with
TF-IDF, cosine similarity and an optional hybrid (rating + popularity)
ranking layer, wrapped in a Streamlit web application and backed by the
TMDB API for live poster artwork.

---

## Overview

Given a movie the user already likes, the system recommends other movies
that are textually and thematically similar — based on genre, plot,
keywords, cast and director — and optionally re-ranks those results using
each candidate's rating and popularity so recommendations are not just
"similar" but also generally well-regarded.

## Problem Statement

With tens of thousands of movies available on streaming platforms,
manually browsing for something to watch is inefficient. Users need a
system that, given one movie they enjoyed, can surface other movies they
are likely to enjoy — without requiring a large history of personal
ratings (which a new user will not yet have).

## Objectives

- Build a content-based recommendation engine using classical NLP/ML
  techniques (TF-IDF + cosine similarity).
- Combine multiple movie attributes (genre, plot, cast, director,
  keywords) into a single feature representation.
- Improve raw similarity ranking with a configurable hybrid score that
  also considers rating and popularity.
- Serve recommendations through a polished, interactive web UI with
  live poster artwork from the TMDB API.
- Follow production-style software engineering practices: modular code,
  environment-based secrets, saved model artifacts, automated tests.

## Features

1. Search and select a movie by title.
2. View full movie details (poster, overview, genres, cast, director,
   rating, release year).
3. Get top-N similar movie recommendations.
4. Toggle between pure content-similarity ranking and hybrid ranking
   (similarity + rating + popularity), with adjustable weights.
5. Browse popular / highly rated movies with genre and rating filters.
6. Graceful handling of missing data, unknown titles, and API failures.

## Machine Learning Approach

**Content-based filtering**: every movie is represented purely by its own
metadata (no other users' behaviour is needed). This avoids the
"cold-start" problem that collaborative filtering has for new items and
new users, at the cost of not capturing cross-user taste patterns (see
*Model Limitations*).

Pipeline:

```
Raw TMDB CSVs
     │
     ▼
Data Preprocessing  (clean, merge, extract genres/cast/director)
     │
     ▼
Feature Engineering (build combined "tags" text → TF-IDF vectors)
     │
     ▼
Recommendation Engine (cosine similarity → optional hybrid re-ranking)
     │
     ▼
Streamlit UI (+ TMDB API for posters)
```

## Dataset

**TMDB 5000 Movie Dataset** — two CSV files:

| File | Contents |
|---|---|
| `tmdb_5000_movies.csv` | title, overview, genres, keywords, popularity, vote_average, vote_count, release_date, ... |
| `tmdb_5000_credits.csv` | movie_id, title, cast, crew (from which director is extracted) |

### Dataset Setup

1. Download the dataset (search "TMDB 5000 Movie Dataset" on Kaggle, or
   use any mirror that provides the same two files with identical column
   names).
2. Place both files here:
   ```
   data/raw/tmdb_5000_movies.csv
   data/raw/tmdb_5000_credits.csv
   ```
3. Run the training script (see *How to Run*) to build model artifacts.

The raw CSVs are **not** committed to source control (see `.gitignore`)
— they must be downloaded locally, which keeps the repository small and
avoids redistributing third-party data.

## Data Preprocessing

Implemented in `src/data_preprocessing.py`:

- Merge `movies` and `credits` on movie title.
- Drop duplicate titles.
- Drop rows with a missing overview (too little content to represent
  the movie); fill other optional fields (tagline, runtime) sensibly
  rather than dropping more data.
- Parse the JSON-like `genres`, `keywords`, `cast` and `crew` columns
  with `ast.literal_eval` (wrapped in a safe helper that tolerates
  malformed rows).
- Extract the top 3 billed cast members and the director's name.
- Normalize text (lower-case, whitespace collapse).
- Build a single combined `tags` column:
  `overview + genres + keywords + top cast + director`.

## Feature Engineering

`src/feature_engineering.py` fits a `TfidfVectorizer` on the `tags`
column with:

- `stop_words='english'` — removes common English stopwords.
- `max_features=5000` — caps vocabulary size for speed and to reduce
  noise from very rare tokens.
- `ngram_range=(1, 2)` — captures both single words and meaningful
  two-word phrases (e.g. "science fiction").
- `min_df=2` — ignores terms that appear in only one movie.

**Why TF-IDF?** It up-weights words that are distinctive to one movie
(a rare keyword, a specific actor) and down-weights words that appear
everywhere in the corpus, all without requiring any labelled training
data — a good fit when only item metadata (no user ratings history) is
available.

## Recommendation Algorithm

`src/recommendation_engine.py`:

```python
def recommend_movies(movie_title, n=10, use_hybrid_ranking=True, weights=None):
    ...
```

1. Look up the queried movie's row index.
2. Compute cosine similarity between its TF-IDF vector and every other
   movie's vector (`sklearn.metrics.pairwise.linear_kernel`, which is
   equivalent to cosine similarity for L2-normalized TF-IDF vectors and
   faster to compute).
3. Remove the queried movie from the candidate list.
4. **Optional hybrid re-ranking**:
   ```
   final_score = similarity_weight   * similarity_score
               + rating_weight       * normalized_rating
               + popularity_weight   * normalized_popularity
   ```
   Default weights: `0.7 / 0.2 / 0.1`. **These are configurable
   parameters, not scientifically optimal values** — they can be tuned
   live from the Streamlit sidebar. A minimum vote-count threshold
   (default 20) prevents an obscure movie with one 10/10 vote from
   dominating the ranking purely on rating.
5. Sort and return the top-N results.

Unknown movie titles raise a `MovieNotFoundError`, handled gracefully by
the UI.

## System Architecture

```
movie-recommendation-system/
│
├── data/
│   ├── raw/                  # tmdb_5000_movies.csv, tmdb_5000_credits.csv (not committed)
│   └── processed/            # processed_movies.csv (generated)
│
├── notebooks/
│   └── movie_recommendation_analysis.ipynb   # EDA + model walkthrough
│
├── src/
│   ├── data_preprocessing.py
│   ├── feature_engineering.py
│   ├── recommendation_engine.py
│   ├── api_client.py
│   ├── train.py               # builds & saves all model artifacts
│   └── utils.py
│
├── models/                    # tfidf_vectorizer.pkl, tfidf_matrix.pkl, movies_artifact.pkl (generated)
│
├── app/
│   └── app.py                 # Streamlit UI
│
├── tests/
│   └── test_recommender.py
│
├── .env.example
├── .gitignore
├── requirements.txt
├── README.md
└── LICENSE
```

## Technology Stack

| Layer | Technology |
|---|---|
| Language | Python 3.10+ |
| Data | Pandas, NumPy |
| ML / NLP | Scikit-learn (TfidfVectorizer, cosine similarity) |
| API | TMDB API (posters, live metadata) |
| Frontend | Streamlit |
| Visualization | Matplotlib, Plotly |
| Persistence | joblib |
| Testing | Pytest |
| Dev environment | Jupyter Notebook |

## Installation

```bash
git clone <your-repo-url>
cd movie-recommendation-system
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## API Configuration

1. Create a free TMDB account and generate an API key:
   https://www.themoviedb.org/settings/api
2. Copy the example env file and fill in your key:
   ```bash
   cp .env.example .env
   ```
   ```
   TMDB_API_KEY=your_tmdb_api_key_here
   ```
3. The app works without a key — poster images fall back to a
   placeholder, and the recommendation engine itself is fully offline.

## How to Run

```bash
# 1. Place tmdb_5000_movies.csv and tmdb_5000_credits.csv in data/raw/

# 2. Build model artifacts (TF-IDF vectorizer, matrix, processed dataset)
python -m src.train

# 3. Launch the web app
streamlit run app/app.py
```

Open the URL Streamlit prints (typically http://localhost:8501).

## Project Structure

See *System Architecture* above.

## Example Output

Querying `recommend_movies("Avatar", n=5)` on the real TMDB 5000 dataset
returns (similarity-only ranking): *Aliens*, *Alien*, *Interstellar*,
*Alien³*, *Moonraker* — genuinely related science-fiction titles, driven
by shared genre, keyword and overview vocabulary.

## Model Limitations

- **Pure content-based**: recommendations reflect textual/metadata
  similarity, not actual user taste — two users who both like "The Dark
  Knight" for different reasons get identical recommendations.
- **No personalization across sessions**: there is no user login or
  rating history, so the system cannot learn an individual's evolving
  preferences.
- **Metadata quality dependent**: a movie with a thin overview or few
  keywords will get a weaker feature representation.
- **No conventional accuracy metric**: without user-interaction ground
  truth, Precision@K/Recall@K cannot be legitimately computed (see the
  notebook's Evaluation section) — we instead report similarity
  distribution, catalogue coverage and qualitative checks.
- **Popularity bias risk**: the hybrid ranking mode can favor
  well-known movies; the minimum vote-count threshold only partly
  mitigates this and the weights are hand-chosen, not learned.

## Future Enhancements

- Collaborative filtering using real user-rating data (e.g. MovieLens).
- Hybrid content + collaborative recommendation.
- User accounts, watchlists and an explicit rating system.
- Sentiment analysis of user reviews as an additional signal.
- Transformer/BERT-based semantic embeddings instead of TF-IDF.
- Neural Collaborative Filtering.
- Recommendation explanations, e.g. "Recommended because you liked
  movies with similar genres, cast, and themes."

## Author

*[Your Name]* — built as an academic AI/ML project.

---

## Testing

```bash
pytest tests/ -v
```

17 unit tests cover the preprocessing helpers, the full preprocessing
pipeline, TF-IDF feature shape, and the recommendation engine (including
error handling for unknown titles).

---

## Viva / Academic Explanation

**1. What is a recommendation system?**
A system that predicts or suggests items (here, movies) a user is likely
to be interested in, based on either the item's own attributes
(content-based) or patterns across many users' behaviour (collaborative).

**2. What is content-based filtering?**
A recommendation approach that represents each item by its own features
(genre, plot, cast, etc.) and recommends items whose feature
representation is most similar to an item the user already likes. It
does not require data about other users.

**3. Why was TF-IDF used?**
TF-IDF converts free text into numerical vectors that emphasize words
distinctive to a specific document (movie) while down-weighting words
common across the whole corpus. It needs no labelled data, is fast, and
is easy to interpret — every dimension corresponds to an actual word.

**4. What is cosine similarity?**
A measure of the angle between two vectors, ranging from -1 to 1 (0 to 1
for non-negative TF-IDF vectors). It captures how similar two documents'
word *patterns* are, independent of document length/vector magnitude —
important because movie overviews vary a lot in length.

**5. Why use Scikit-learn?**
It provides well-tested, efficient implementations of `TfidfVectorizer`
and pairwise similarity functions, avoiding the need to reimplement
standard NLP/ML routines from scratch, and is the de-facto standard
library for classical ML in Python.

**6. Why is Pandas used?**
For loading, cleaning, merging and transforming the tabular CSV data —
handling missing values, merging the movies and credits tables, and
building the combined `tags` feature column.

**7. How does the API work?**
The Streamlit app calls the TMDB REST API (`GET /movie/{id}`) with an
API key read from an environment variable, to fetch live poster/backdrop
image paths. Every call is wrapped in error handling with a timeout; on
any failure it falls back to a placeholder image rather than crashing.

**8. How are movie features generated?**
By parsing the JSON-like `genres`, `keywords`, `cast` and `crew` fields
into plain text tokens, combining them with the cleaned plot overview
into one `tags` string per movie, then vectorizing that string with
TF-IDF.

**9. How does the system recommend a movie?**
It finds the queried movie's TF-IDF vector, computes cosine similarity
against every other movie's vector, optionally blends in normalized
rating/popularity, and returns the top-N highest-scoring movies
(excluding the queried movie itself).

**10. What are the limitations?**
See *Model Limitations* above — no personalization, no true accuracy
metric without user data, dependent on metadata quality, and potential
popularity bias in hybrid mode.

**11. Difference between content-based and collaborative filtering?**
Content-based filtering compares item *attributes*; it works for new
items with no interaction history but cannot capture "users like you
also enjoyed..." patterns. Collaborative filtering compares user/item
*interaction patterns* (ratings, clicks); it can surface non-obvious
recommendations but suffers from the cold-start problem for new items
or new users with no history.

**12. Why is this considered an AIML project?**
It applies core machine learning / NLP techniques — text vectorization
(TF-IDF), vector-space similarity computation, and a weighted scoring
model — to solve a real recommendation problem, following a proper
ML pipeline (data preprocessing → feature engineering → model →
evaluation → deployment).

**13. How can the project be improved using deep learning?**
Replace TF-IDF with transformer-based sentence embeddings (e.g. BERT /
Sentence-BERT) to capture semantic similarity beyond exact word overlap,
or use Neural Collaborative Filtering once real user-interaction data is
available.

**14. What would change if real user-rating data were available?**
A collaborative filtering or hybrid model could be trained (e.g. matrix
factorization, Neural Collaborative Filtering), true Precision@K /
Recall@K evaluation would become possible against held-out user
ratings, and recommendations could become genuinely personalized per
user rather than purely content-driven.

---

## Resume-Ready Project Description

> **Intelligent Movie Recommendation System** — Built a content-based
> movie recommender using TF-IDF vectorization and cosine similarity
> over the TMDB 5000 dataset (4,800+ movies), with a configurable hybrid
> ranking layer blending content similarity, rating and popularity.
> Designed a modular, production-style ML pipeline (preprocessing →
> feature engineering → model → persisted artifacts) and a Streamlit
> web application with live poster retrieval via the TMDB API, graceful
> API-failure fallback, and 17 automated unit tests.

## GitHub-Ready Project Description

> Content-based movie recommendation engine (TF-IDF + cosine similarity,
> optional hybrid rating/popularity re-ranking) over the TMDB 5000
> dataset, served through a Streamlit UI with TMDB API poster
> integration. Modular Python codebase, persisted model artifacts,
> pytest test suite, and a documented EDA/evaluation notebook.
