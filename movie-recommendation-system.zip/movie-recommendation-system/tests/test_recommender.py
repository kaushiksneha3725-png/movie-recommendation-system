"""
test_recommender.py
---------------------
Basic unit tests for the preprocessing pipeline and recommendation
engine. Run with:

    pytest tests/ -v

These tests use the real (small, fast-to-process) TMDB dataset rather
than mocks, since the whole pipeline runs in a few seconds and testing
against real data catches real bugs (e.g. malformed genre strings).
"""

import pandas as pd
import pytest

from src.data_preprocessing import (
    clean_dataset,
    extract_director,
    extract_genre_names,
    extract_keyword_names,
    extract_top_cast,
    run_preprocessing,
)
from src.feature_engineering import build_tfidf_features
from src.recommendation_engine import (
    MovieNotFoundError,
    RankingWeights,
    RecommendationEngine,
)


@pytest.fixture(scope="module")
def processed_movies():
    return run_preprocessing()


@pytest.fixture(scope="module")
def engine(processed_movies):
    _, matrix = build_tfidf_features(processed_movies["tags"])
    return RecommendationEngine(processed_movies, matrix)


# ---------------------------------------------------------------------------
# Preprocessing helper functions
# ---------------------------------------------------------------------------

def test_extract_genre_names_parses_json_like_string():
    raw = "[{'id': 28, 'name': 'Action'}, {'id': 12, 'name': 'Adventure'}]"
    assert extract_genre_names(raw) == ["Action", "Adventure"]


def test_extract_genre_names_handles_malformed_input():
    assert extract_genre_names("not valid json") == []
    assert extract_genre_names(None) == []


def test_extract_top_cast_limits_and_strips_spaces():
    raw = "[{'name': 'Sam Worthington'}, {'name': 'Zoe Saldana'}, {'name': 'A'}, {'name': 'B'}]"
    result = extract_top_cast(raw, top_n=2)
    assert result == ["SamWorthington", "ZoeSaldana"]


def test_extract_director_finds_director_job_only():
    raw = "[{'name': 'Jane Editor', 'job': 'Editor'}, {'name': 'John Doe', 'job': 'Director'}]"
    assert extract_director(raw) == ["JohnDoe"]


def test_extract_director_returns_empty_when_missing():
    raw = "[{'name': 'Jane Editor', 'job': 'Editor'}]"
    assert extract_director(raw) == []


# ---------------------------------------------------------------------------
# Full preprocessing pipeline
# ---------------------------------------------------------------------------

def test_run_preprocessing_produces_expected_columns(processed_movies):
    expected_columns = {"title", "tags", "vote_average", "vote_count", "popularity"}
    assert expected_columns.issubset(set(processed_movies.columns))


def test_no_duplicate_titles(processed_movies):
    assert processed_movies["title"].duplicated().sum() == 0


def test_no_missing_tags(processed_movies):
    assert processed_movies["tags"].isnull().sum() == 0
    assert (processed_movies["tags"].str.len() > 0).all()


# ---------------------------------------------------------------------------
# Feature engineering
# ---------------------------------------------------------------------------

def test_tfidf_matrix_shape_matches_movie_count(processed_movies):
    vectorizer, matrix = build_tfidf_features(processed_movies["tags"])
    assert matrix.shape[0] == len(processed_movies)
    assert matrix.shape[1] == len(vectorizer.vocabulary_)


# ---------------------------------------------------------------------------
# Recommendation engine
# ---------------------------------------------------------------------------

def test_recommend_movies_returns_requested_count(engine):
    recs = engine.recommend_movies("Avatar", n=5)
    assert len(recs) == 5


def test_recommend_movies_excludes_queried_movie(engine):
    recs = engine.recommend_movies("Avatar", n=10)
    assert "Avatar" not in recs["title"].values


def test_recommend_movies_raises_for_unknown_title(engine):
    with pytest.raises(MovieNotFoundError):
        engine.recommend_movies("This Movie Does Not Exist 12345", n=5)


def test_recommend_movies_similarity_only_vs_hybrid_can_differ(engine):
    sim_only = engine.recommend_movies("Avatar", n=10, use_hybrid_ranking=False)
    hybrid = engine.recommend_movies("Avatar", n=10, use_hybrid_ranking=True)
    # Both should return valid, non-empty recommendation sets.
    assert len(sim_only) == 10
    assert len(hybrid) == 10


def test_ranking_weights_normalize_to_sum_one():
    weights = RankingWeights(similarity_weight=2, rating_weight=1, popularity_weight=1)
    normalized = weights.normalized()
    total = (
        normalized.similarity_weight
        + normalized.rating_weight
        + normalized.popularity_weight
    )
    assert abs(total - 1.0) < 1e-9


def test_popular_movies_respects_minimum_vote_count(engine):
    popular = engine.popular_movies(n=10, minimum_vote_count=1000)
    assert (popular["vote_count"] >= 1000).all()


def test_search_titles_is_case_insensitive(engine):
    results = engine.search_titles("avatar")
    assert any("Avatar" in title for title in results)


def test_get_movie_details_returns_series(engine):
    details = engine.get_movie_details("Avatar")
    assert isinstance(details, pd.Series)
    assert details["title"] == "Avatar"
